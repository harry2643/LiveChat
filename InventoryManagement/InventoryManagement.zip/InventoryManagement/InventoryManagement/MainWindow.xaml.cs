﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace InventoryManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ServiceReference1.Service1Client client = new
            ServiceReference1.Service1Client();
            var j = client.GetDataTable();

            List<Product> studentList = new List<Product>();
            for (int i = 0; i < j.Rows.Count; i++)
            {
                Product student = new Product();
                student.Prduct_id = Convert.ToInt32(j.Rows[i]["Prduct_id"]);
                student.Product_name = j.Rows[i]["Product_name"].ToString();
                student.Quantity = Convert.ToInt32(j.Rows[i]["Quantity"]);
                //student.MobileNo = dt.Rows[i]["MobileNo"].ToString();
                studentList.Add(student);
            }  


//            var categoryList = new List<Product>(j.Rows.Count);
            anc.ItemsSource = studentList;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Orders orders = new Orders();
            orders.Show();
            
        }
    }
}
