﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace InventoryManagement
{
    /// <summary>
    /// Interaction logic for Orders.xaml
    /// </summary>
    public partial class Orders : Window
    {
        InventoryDatabaseEntities id = new InventoryDatabaseEntities();

        public Orders()
        {
            InitializeComponent();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        { 
        
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
          
            Order order = new Order();
            Product products = new Product();
            var query =
            from product in id.Products
            where product.Product_name == txt_productname.Text
            select product.Prduct_id;

           
            //order.Product_id = Convert.ToInt32(query.FirstOrDefault());
            //order.Quantity = Convert.ToInt32(txt_quantity.Text);

            int Product_id = Convert.ToInt32(query.FirstOrDefault());
            int Quantity = Convert.ToInt32(txt_quantity.Text);

            //id.Orders.Add(order);

            ServiceReference1.Service1Client client = new
          ServiceReference1.Service1Client();

            client.Insert(Product_id, Quantity);


            var query1 =
            from ord in id.Products
            where ord.Prduct_id == Product_id
            select ord.Quantity;

            // int q = Convert.ToInt32(txt_quantity.Text);

            int quantitypro = Convert.ToInt32(query1.FirstOrDefault());
            int newquantity=quantitypro-Quantity;


            client.Update(Product_id, newquantity);

           

        }
    }
}
