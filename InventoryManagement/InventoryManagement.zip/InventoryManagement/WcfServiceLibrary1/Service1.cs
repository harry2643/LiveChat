﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using InventoryManagement;
using System.Data.SqlClient;
using System.Data;

namespace WcfServiceLibrary1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
        public DataTable GetDataTable()
        {

            string connectionstring = "Persist Security Info=False;Integrated Security=true;Initial Catalog=InventoryDatabase;server='HARMEET-PC\\SQLEXPRESS'";

            using (SqlConnection con = new SqlConnection(connectionstring))
            {

                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Products"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            dt.TableName = "Products";
                            sda.Fill(dt);
                            return dt;
                        }

                    }
                }
            }
        }




        public void Insert(int productid, int quantity)
        {
            string connectionstring1 = "Persist Security Info=False;Integrated Security=true;Initial Catalog=InventoryDatabase;server='HARMEET-PC\\SQLEXPRESS'";

            using (SqlConnection con = new SqlConnection(connectionstring1))
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Orders (Product_id,Description,Quantity) VALUES (@ProductId, @Description,@Quantity)"))
                {
                    cmd.Parameters.AddWithValue("@ProductId", productid);
                    cmd.Parameters.AddWithValue("@Description", "Hi");
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }

        
        }

        public void Update(int productid, int quantity)
        {
            string connectionstring1 = "Persist Security Info=False;Integrated Security=true;Initial Catalog=InventoryDatabase;server='HARMEET-PC\\SQLEXPRESS'";

            using (SqlConnection con = new SqlConnection(connectionstring1))
            {
                using (SqlCommand cmd = new SqlCommand("update Products set Quantity='" + quantity+"' where Prduct_id='" + productid + "'"))
                {
                   
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }


        }

    }
}
